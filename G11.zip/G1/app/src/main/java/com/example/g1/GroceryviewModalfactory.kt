package com.example.g1

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class GroceryviewModalfactory(private val repository: GroceryRepository) : ViewModelProvider.NewInstanceFactory() {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return Groceryviewmodal(repository) as T
    }
}