package com.example.g1

import android.app.Dialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton


class MainActivity : AppCompatActivity(), GroceryRVAdapter.GroceryItemClickInterface {
    lateinit var itemsRV: RecyclerView
    lateinit var addFAB: FloatingActionButton
    lateinit var list: List<GroceryItems>
    lateinit var groceryRVAdapter: GroceryRVAdapter
    lateinit var groceryviewmodal: Groceryviewmodal
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        itemsRV = findViewById(R.id.IdRVItem)
        addFAB = findViewById(R.id.idFABdd)
        list = ArrayList<GroceryItems>()
        groceryRVAdapter = GroceryRVAdapter(list, this)
        itemsRV.layoutManager = LinearLayoutManager(this)
        itemsRV.adapter = groceryRVAdapter
        val groceryRepository = GroceryRepository(GroceryDatabase(this))
        val factory = GroceryviewModalfactory(groceryRepository)
        groceryviewmodal = ViewModelProvider(this,factory).get(Groceryviewmodal::class.java)

        groceryviewmodal.getallGroceryItems().observe(this, {
            groceryRVAdapter.list = it
            groceryRVAdapter.notifyDataSetChanged()
        })
         addFAB.setOnClickListener {
             openDialog()

         }
    }


    fun openDialog() {
        var dialog = Dialog(this)
        dialog.setContentView(R.layout.grocerry_add_dialog)
        val cancelbtn = dialog.findViewById<Button>(R.id.idBtnCancle)
        val addBtn = dialog.findViewById<Button>(R.id.idBtnAdd)
        val itemEdt = dialog.findViewById<EditText>(R.id.idEdtItemName)
        val itemPriceEdt = dialog.findViewById<EditText>(R.id.idEdtItemPrice)
        val itemQuantityEdt = dialog.findViewById<EditText>(R.id.idEdtItemQuantity)
        cancelbtn.setOnClickListener{
            dialog.dismiss()
        }
        addBtn.setOnClickListener{
            val itemName : String = itemEdt.text.toString()
            val itemPrice : String = itemPriceEdt.text.toString()
            val itemquantity : String = itemQuantityEdt.text.toString()
            val qty : Int = itemquantity.toInt()
            val pr : Int = itemPrice.toInt()
            if(itemName.isNotEmpty() && itemPrice.isNotEmpty() && itemquantity.isNotEmpty()){
                val items = GroceryItems(itemName,qty,pr)
                groceryviewmodal.insert(items)
                Toast.makeText(applicationContext, "Item Inserted...",Toast.LENGTH_SHORT).show()
                groceryRVAdapter.notifyDataSetChanged()
                dialog.dismiss()
            }else{
                Toast.makeText(applicationContext, "enter all the data ",Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    override fun onItemClick(groceryItems: GroceryItems) {
        groceryviewmodal.delete(groceryItems)
        groceryRVAdapter.notifyDataSetChanged()
        Toast.makeText(applicationContext, "Item Delete Sucesfully",Toast.LENGTH_SHORT).show()
    }

}